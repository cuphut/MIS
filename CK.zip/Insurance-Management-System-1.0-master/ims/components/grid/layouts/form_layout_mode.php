<?php

class FormLayoutMode
{
    const HORIZONTAL = 'horizontal';
    const VERTICAL = 'vertical';
}
